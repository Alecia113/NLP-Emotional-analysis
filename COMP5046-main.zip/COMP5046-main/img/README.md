Images for A1 specification.
