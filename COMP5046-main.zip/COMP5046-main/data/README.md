Data for COMP5046 A1.
- Opinion Lexicon file
